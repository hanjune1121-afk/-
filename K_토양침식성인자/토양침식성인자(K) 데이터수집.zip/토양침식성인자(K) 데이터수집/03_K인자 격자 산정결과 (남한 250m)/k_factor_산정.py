"""RUSLE 토양침식성인자(K) 격자 산정 — 남한 전역, SoilGrids 2.0 공개자료.

입력 : ISRIC SoilGrids 2.0 (CC-BY 4.0, 신청 없이 WCS로 내려받음)
       sand·silt·clay [g/kg], soc [dg/kg] × 0-5, 5-15, 15-30 cm
       남한 경계: Natural Earth 10m admin-0 (퍼블릭 도메인)
깊이 : 0-30 cm 층두께 가중평균 (「표토의 침식 현황 조사에 관한 고시」 현장조사 심도 30 cm)
식   : Williams (1995) EPIC → SI 단위 Mg·ha·hr/(ha·MJ·mm) (= 고시 표2와 같은 단위)
출력 : K_남한_250m_EPSG5179.tif, K_남한_지도.png
사용 : python k_factor_산정.py <SoilGrids tif 폴더> <남한경계.geojson> <출력 폴더>
"""
import json
import sys
from pathlib import Path

import numpy as np
import rasterio
from rasterio.features import rasterize
from rasterio.warp import calculate_default_transform, reproject, Resampling

DEPTHS = {"0-5cm": 5, "5-15cm": 10, "15-30cm": 15}
DST_CRS = "EPSG:5179"  # Korea 2000 / Unified CS — 토지피복지도와 같은 좌표계


def load_topsoil(src_dir, prop):
    acc, wsum = None, 0
    for d, w in DEPTHS.items():
        with rasterio.open(src_dir / f"{prop}_{d}.tif") as r:
            a = r.read(1).astype("float64")
            profile = r.profile
        a[a <= 0] = np.nan  # 0 = 바다/자료 없음
        acc = a * w if acc is None else acc + a * w
        wsum += w
    return acc / wsum, profile


def k_epic(sand, silt, clay, oc):
    """Williams (1995) EPIC. 입력은 %. 반환값 SI 단위 K."""
    sn1 = 1 - sand / 100
    f_csand = 0.2 + 0.3 * np.exp(-0.256 * sand * (1 - silt / 100))
    f_clsi = (silt / (clay + silt)) ** 0.3
    f_orgc = 1 - 0.25 * oc / (oc + np.exp(3.72 - 2.95 * oc))
    f_hisand = 1 - 0.7 * sn1 / (sn1 + np.exp(-5.51 + 22.9 * sn1))
    return f_csand * f_clsi * f_orgc * f_hisand * 0.1317


def main(src_dir, boundary, out_dir):
    src_dir, out_dir = Path(src_dir), Path(out_dir)
    sand, prof = load_topsoil(src_dir, "sand")
    silt, _ = load_topsoil(src_dir, "silt")
    clay, _ = load_topsoil(src_dir, "clay")
    soc, _ = load_topsoil(src_dir, "soc")
    tot = sand + silt + clay
    k = k_epic(sand / tot * 100, silt / tot * 100, clay / tot * 100, soc / 100)

    geoms = [f["geometry"] for f in json.load(open(boundary, encoding="utf-8"))["features"]]
    inside = rasterize(geoms, out_shape=k.shape, transform=prof["transform"], fill=0, default_value=1,
                       all_touched=True).astype(bool)
    k[~inside] = np.nan
    k = np.where(np.isnan(k), -9999.0, k).astype("float32")

    tr, w, h = calculate_default_transform(prof["crs"], DST_CRS, prof["width"], prof["height"],
                                           *rasterio.transform.array_bounds(prof["height"], prof["width"],
                                                                            prof["transform"]),
                                           resolution=250)
    out = np.full((h, w), -9999.0, dtype="float32")
    reproject(k, out, src_transform=prof["transform"], src_crs=prof["crs"], dst_transform=tr,
              dst_crs=DST_CRS, src_nodata=-9999.0, dst_nodata=-9999.0, resampling=Resampling.bilinear)
    rows, cols = np.where(out != -9999.0)
    r0, r1, c0, c1 = rows.min(), rows.max() + 1, cols.min(), cols.max() + 1  # 자료 범위로 자르기
    out = out[r0:r1, c0:c1]
    tr = tr * rasterio.Affine.translation(c0, r0)
    p = dict(driver="GTiff", dtype="float32", count=1, width=out.shape[1], height=out.shape[0],
             crs=DST_CRS, transform=tr, nodata=-9999.0, compress="deflate", predictor=3, tiled=True)
    with rasterio.open(out_dir / "K_남한_250m_EPSG5179.tif", "w", **p) as dst:
        dst.write(out, 1)
        dst.update_tags(1, UNITS="Mg·ha·hr/(ha·MJ·mm)", METHOD="Williams(1995) EPIC, topsoil 0-30cm",
                        SOURCE="ISRIC SoilGrids 2.0 (CC-BY 4.0)")

    v = out[out != -9999.0]
    print(f"cells={v.size}  mean={v.mean():.4f}  p5={np.percentile(v, 5):.4f}  "
          f"p50={np.percentile(v, 50):.4f}  p95={np.percentile(v, 95):.4f}  min={v.min():.4f}  max={v.max():.4f}")

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(7, 8))
    ext = (tr.c, tr.c + tr.a * out.shape[1], tr.f + tr.e * out.shape[0], tr.f)
    im = ax.imshow(np.ma.masked_equal(out, -9999.0), extent=ext, cmap="YlOrBr",
                   vmin=np.percentile(v, 2), vmax=np.percentile(v, 98))
    ax.set_title("RUSLE K factor, South Korea (SoilGrids 2.0, 0-30 cm, EPIC)")
    ax.set_xlabel("X (m, EPSG:5179)"); ax.set_ylabel("Y (m, EPSG:5179)")
    ax.ticklabel_format(style="plain"); ax.tick_params(labelsize=7)
    cb = fig.colorbar(im, ax=ax, shrink=0.75); cb.set_label("K  [Mg·ha·hr/(ha·MJ·mm)]")
    fig.tight_layout(); fig.savefig(out_dir / "K_남한_지도.png", dpi=150); plt.close(fig)


if __name__ == "__main__":
    main(*sys.argv[1:4])
