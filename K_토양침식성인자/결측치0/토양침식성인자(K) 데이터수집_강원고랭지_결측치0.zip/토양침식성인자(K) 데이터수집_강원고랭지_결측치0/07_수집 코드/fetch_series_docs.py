"""흙토람 > 토양통 검색 > 한글설명 원문(HTML·PDF) 내려받기 + 대표토양 분석치 표 정리.

대상: 지역 보고서(지역별_토양부호_면적_K값.csv)에 나온 토양통
출력:
  <docs>/<토양통>_<영문>.pdf, .htm   : 흙토람 원문 그대로
  <out>/토양통_대표토양_분석치.csv    : 토층별 입경(모래·미사·점토·극세사 등)·용적밀도·pH·유기탄소
사용: python fetch_series_docs.py <series_all.csv> <지역별_토양부호_면적_K값.csv> <docs 폴더> <출력 csv> [i/n]
"""
import re, subprocess, sys, time
from pathlib import Path

import pandas as pd

PHYS = ["토층", "토심(cm)", "모래(%)", "미사(%)", "점토(%)", "토성", "극조사(%)", "조사(%)", "중사(%)",
        "세사(%)", "극세사(%)", "용적밀도(Mg/m3)", "수분장력10kPa", "수분장력33kPa", "수분장력1500kPa"]
CHEM = ["토층", "토심(cm)", "pH(H2O)", "pH(KCl)", "유기탄소(g/kg)", "염기치환용량(cmol/kg)",
        "Ca", "Mg", "K", "Na", "염기포화도(%)"]


def get(url, out, tries=8):
    for _ in range(tries):
        r = subprocess.run(["curl", "-sL", "-m", "90", "-o", str(out), "-w", "%{http_code}", url],
                           capture_output=True, text=True)
        if r.returncode == 0 and r.stdout == "200" and out.exists() and out.stat().st_size > 0:
            return True
        time.sleep(3)
    out.unlink(missing_ok=True)
    return False


def tables(html):
    res = []
    for tb in re.findall(r"<table.*?</table>", html, re.S | re.I):
        rows = []
        for r in re.findall(r"<tr.*?</tr>", tb, re.S | re.I):
            rows.append([re.sub(r"\s+", " ", re.sub(r"<[^>]+>", "", c).replace("&nbsp;", " ")).strip()
                         for c in re.findall(r"<t[dh][^>]*>(.*?)</t[dh]>", r, re.S | re.I)])
        res.append(rows)
    return res


def parse(html):
    phys, chem = {}, {}
    for rows in tables(html):
        flat = " ".join(" ".join(r) for r in rows[:3])
        target, names = (phys, PHYS) if "모래" in flat else (chem, CHEM) if "유기탄소" in flat else (None, None)
        if target is None:
            continue
        for r in rows:
            if r and re.match(r"^(표토|심토|모재|기층|Ap|A|B|C)", r[0]) and len(r) >= len(names) - 3:
                target[r[0]] = dict(zip(names, r))
    out = []
    for h in phys.keys() | chem.keys():
        rec = {**phys.get(h, {}), **chem.get(h, {})}
        rec["토층"] = h
        out.append(rec)
    return out


def main(series_csv, region_csv, docs, out_csv, shard="0/1"):
    docs = Path(docs); docs.mkdir(parents=True, exist_ok=True)
    s = pd.read_csv(series_csv).drop_duplicates("토양통")
    need = pd.read_csv(region_csv)
    names = sorted(set(need.loc[need["K값_연결방법"] != "토양 아님", "토양통"].dropna()))
    si, sn = map(int, shard.split("/"))
    names = names[si::sn]
    recs = []
    for n in names:
        row = s[s["토양통"] == n]
        if row.empty or not isinstance(row.iloc[0]["한글설명_URL"], str):
            print("목록에 없음:", n); continue
        url = row.iloc[0]["한글설명_URL"]
        stem = f"{n}_{row.iloc[0]['영문']}"
        htm = docs / f"{stem}.htm"
        if not (htm.exists() or get(url, htm)):
            print("HTML 실패:", n); continue
        html = htm.read_bytes().decode("utf-8-sig", errors="ignore")
        pdf = re.search(r'href="([^"]+\.pdf)"', html, re.I)
        if pdf:
            p = docs / f"{stem}.pdf"
            if not (p.exists() or get(url.rsplit("/", 1)[0] + "/" + pdf.group(1), p)):
                print("PDF 실패:", n)
        hz = parse(html)
        if not hz:
            print("분석치 없음:", n)
        order = 0
        for h in sorted(hz, key=lambda r: float(re.match(r"[\d.]+", r.get("토심(cm)", "999") or "999").group())
                        if re.match(r"[\d.]+", r.get("토심(cm)", "") or "") else 999):
            order += 1
            recs.append({"토양통": n, "영문": row.iloc[0]["영문"], "층순서": order, **h, "원문": url})
        time.sleep(0.5)
    if sn > 1:
        return  # 나눠 받을 때는 마지막에 shard 없이 한 번 더 실행해 표를 만든다
    df = pd.DataFrame(recs)
    cols = ["토양통", "영문", "층순서"] + [c for c in PHYS + CHEM[2:] if c in df.columns] + ["원문"]
    df[cols].to_csv(out_csv, index=False, encoding="utf-8-sig")
    print(len(names), "토양통 /", df["토양통"].nunique(), "분석치 있음 /", len(df), "층")


if __name__ == "__main__":
    main(*sys.argv[1:6])
