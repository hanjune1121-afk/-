"""흙토람 토양특성 통계 원본 엑셀(표토토성·표토자갈함량·구조·배수등급·침식등급) → 지역 × 항목 × 구분 면적표.
사용: python build_props_table.py <raw_props 폴더> <출력 csv>
"""
import re, sys
from pathlib import Path

import pandas as pd

recs = []
for f in sorted(Path(sys.argv[1]).glob("*.xls")):
    v = pd.read_excel(f, header=None, engine="xlrd")
    region = item = None
    hdr = None
    for i, row in v.iterrows():
        vals = [str(x).strip() for x in row if pd.notna(x)]
        if "선택지역" in vals:
            region = vals[vals.index("선택지역") + 1]
        m = [x for x in vals if x.startswith("토양통계")]
        if m:
            item = re.sub(r".*\((.*)\).*", r"\1", m[0])
        if "합계" in vals and hdr is None and not any(re.fullmatch(r"[\d,.]+", x) for x in vals):
            hdr = i
            break
    if hdr is None:
        print("표 없음:", f.name); continue
    heads = {j: re.sub(r"\s+", " ", str(v.iat[hdr, j])).strip() for j in range(v.shape[1]) if pd.notna(v.iat[hdr, j])}
    for i in range(hdr + 1, len(v)):
        label = next((str(x).strip() for x in v.iloc[i, :min(heads)] if pd.notna(x)), "")
        nums = {h: v.iat[i, j] for j, h in heads.items() if pd.notna(v.iat[i, j])}
        if not nums:
            continue
        for h, x in nums.items():
            try:
                area = float(str(x).replace(",", ""))
            except ValueError:
                continue
            recs.append({"파일": f.stem, "지역": region, "항목": item, "행": label or "합계", "구분": h, "면적_ha": area})
df = pd.DataFrame(recs)
df.to_csv(sys.argv[2], index=False, encoding="utf-8-sig")
print(df.groupby("항목").size().to_string())
print(df.head(12).to_string())
