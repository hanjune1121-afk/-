"""흙토람 > 토양통 검색 목록(HTML) → 토양부호별 표토토성·경사 표.
사용: python parse_series_list.py <목록 html 폴더> <출력 csv>
"""
import html, re, sys
from pathlib import Path

import pandas as pd

rows = []
for f in sorted(Path(sys.argv[1]).glob("p*.html"), key=lambda p: int(p.stem[1:])):
    t = f.read_text(encoding="utf-8", errors="ignore")
    body = t[t.find("<tbody"):t.find("</tbody>")]
    for tr in re.findall(r"<tr>(.*?)</tr>", body, re.S):
        tds = re.findall(r"<td[^>]*>(.*?)</td>", tr, re.S)
        if len(tds) < 3:
            continue
        name = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", "", tds[0])).strip()
        kor = re.search(r"openwin\('([^']+k\.htm)'\)", tr)
        eng = re.search(r"openwin\('([^']+e\.htm)'\)", tr)
        tips = re.findall(r"popUp\('overDiv', event,'([^']*)'\)", tds[1])
        nm = re.match(r"([^(]+)\(([^,]*),?([^)]*)\)", name)
        base = {"토양통": nm.group(1).strip() if nm else name, "한자": nm.group(2).strip() if nm else "",
                "영문": nm.group(3).strip() if nm else "",
                "한글설명_URL": "https://soil.rda.go.kr" + kor.group(1) if kor else "",
                "영문설명_URL": "https://soil.rda.go.kr" + eng.group(1) if eng else ""}
        if not tips:
            rows.append({**base, "토양부호": "", "부호설명(원문)": ""})
        for tip in tips:
            tip = html.unescape(tip).strip()
            code = tip.split()[0] if tip else ""
            rows.append({**base, "토양부호": code, "부호설명(원문)": tip})
df = pd.DataFrame(rows).drop_duplicates()
m = df["부호설명(원문)"].str.extract(r"^\S+\s+(.*?)\s+([\d.]+\s*-\s*[\d.]+%|[\d.]+%\s*이상|[\d.]+%\s*이하)?\s*경사?$")
df["표토토성"] = m[0]
df["경사"] = m[1]
df.to_csv(sys.argv[2], index=False, encoding="utf-8-sig")
print(len(df), df["토양통"].nunique(), df["표토토성"].isna().sum())
print(df.head(8).to_string())
