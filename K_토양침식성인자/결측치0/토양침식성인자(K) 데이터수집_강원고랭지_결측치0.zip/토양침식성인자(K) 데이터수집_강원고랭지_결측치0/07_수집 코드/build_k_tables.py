"""흙토람 원본 보고서(토양통·부호 면적표) + 고시 표2(토양통별 K값) → 지역별 K 정리표.

입력
  raw/*.xls             : 흙토람 > 토양통계 > 토양통·부호 > 토양별 토지이용 추천표 (원본 엑셀 내보내기)
  토양부호별_K값.csv     : 「표토의 침식 현황 조사에 관한 고시」 별표1 표2 (토양부호 → K)
  토양통별_K값.csv       : 같은 표 (토양통 → K)
출력 (out 폴더)
  지역별_토양부호_면적_K값.csv : 지역 × 토양부호 행, 토지이용추천별 면적(ha) + K값
  지역별_K값_요약.csv          : 지역별 면적가중 평균 K (전체 / 밭 / 논 / 과수·상전 / 초지 / 임지)
  지역별_K값_정리.xlsx         : 위 두 표 + 지역별 시트
사용: python build_k_tables.py <raw 폴더> <K표 폴더> <출력 폴더>
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd

USES = ["논", "밭", "과수/상전", "초지", "임지"]
NON_SOIL = {"하천범람지", "하해범람지", "암석지", "암석노출지", "소택지", "제방", "저수지", "하천", "기타", "수면", "도시"}


def parse_report(path):
    v = pd.read_excel(path, header=None, engine="xlrd")
    region = None
    hdr = None
    for i, row in v.iterrows():
        vals = [str(x).strip() for x in row if pd.notna(x)]
        if "선택지역" in vals:
            region = vals[vals.index("선택지역") + 1]
        if "토양통" in vals and "토양부호" in vals:
            hdr = i
            break
    cols = {str(v.iat[hdr, j]).strip(): j for j in range(v.shape[1]) if pd.notna(v.iat[hdr, j])}
    recs, cur, other = [], None, None
    for i in range(hdr + 1, len(v)):
        name = v.iat[i, cols["토양통"]]
        code = v.iat[i, cols["토양부호"]]
        text = " ".join(str(x) for x in v.iloc[i] if pd.notna(x))
        if "기타" in text and "면적" in text:
            nums = [x for x in v.iloc[i] if isinstance(x, (int, float)) and pd.notna(x)]
            other = float(nums[-1]) if nums else None
        if pd.notna(name) and str(name).strip() == "합계":
            continue
        if pd.isna(code) or str(code).strip() in ("토양부호", ""):
            continue
        if pd.notna(name) and str(name).strip() not in ("토양통",):
            cur = str(name).strip()
        rec = {"토양통": cur, "토양부호": str(code).strip()}
        for u in USES + ["합계"]:
            x = v.iat[i, cols[u]]
            rec[u] = float(str(x).replace(",", "")) if pd.notna(x) else 0.0
        recs.append(rec)
    return region, pd.DataFrame(recs), other


def wavg(k, w):
    m = k.notna() & (w > 0)
    return float(np.average(k[m], weights=w[m])) if w[m].sum() > 0 else np.nan


def main(raw, ktab, out):
    raw, ktab, out = Path(raw), Path(ktab), Path(out)
    out.mkdir(parents=True, exist_ok=True)
    by_code = pd.read_csv(ktab / "토양부호별_K값.csv").set_index("토양부호").iloc[:, -1]
    by_name = pd.read_csv(ktab / "토양통별_K값.csv").set_index("토양통").iloc[:, -1]

    rows, summ, sheets = [], [], {}
    for f in sorted(raw.glob("*.xls")):
        region, df, other = parse_report(f)
        df.insert(0, "지역", region)
        df.insert(0, "파일", f.stem)
        k_code = df["토양부호"].map(by_code)
        k_name = df["토양통"].map(by_name)
        df["K값"] = k_code.fillna(k_name)
        df["K값_연결방법"] = np.where(k_code.notna(), "토양부호 일치",
                                  np.where(k_name.notna(), "토양통명 일치",
                                           np.where(df["토양통"].isin(NON_SOIL), "토양 아님", "표2에 없음")))
        rows.append(df)
        sheets[f.stem] = df.drop(columns=["파일"])

        soil = df[df["K값_연결방법"] != "토양 아님"]
        s = {"파일": f.stem, "지역": region, "총면적_ha(합계)": df["합계"].sum(),
             "기타면적_ha(보고서 표기)": other,
             "K연결_면적비율(%)": round(soil.loc[soil["K값"].notna(), "합계"].sum() / soil["합계"].sum() * 100, 1)}
        s["K_면적가중평균_전체"] = wavg(df["K값"], df["합계"])
        for u in USES:
            s[f"K_면적가중평균_{u.replace('/', '·')}"] = wavg(df["K값"], df[u])
            s[f"면적_ha_{u.replace('/', '·')}"] = df[u].sum()
        top = soil.groupby("토양통")["합계"].sum().sort_values(ascending=False).head(3)
        s["주요 토양통(면적 상위3)"] = ", ".join(f"{n}({by_name.get(n, np.nan):.4f})" for n in top.index)
        summ.append(s)

    long = pd.concat(rows, ignore_index=True)
    summary = pd.DataFrame(summ)
    for c in summary.columns:
        if c.startswith("K_"):
            summary[c] = summary[c].round(4)
    long.to_csv(out / "지역별_토양부호_면적_K값.csv", index=False, encoding="utf-8-sig")
    summary.to_csv(out / "지역별_K값_요약.csv", index=False, encoding="utf-8-sig")
    with pd.ExcelWriter(out / "지역별_K값_정리.xlsx", engine="openpyxl") as w:
        summary.to_excel(w, sheet_name="요약", index=False)
        long.to_excel(w, sheet_name="전체_토양부호별", index=False)
        for name, d in sheets.items():
            d.to_excel(w, sheet_name=name[:31], index=False)
    miss = long[long["K값_연결방법"] == "표2에 없음"][["토양통", "토양부호"]].drop_duplicates()
    print(summary[["파일", "K_면적가중평균_전체", "K_면적가중평균_밭", "면적_ha_밭", "K연결_면적비율(%)"]].to_string())
    print("표2에 없는 토양부호:", miss.values.tolist())


if __name__ == "__main__":
    main(*sys.argv[1:4])
