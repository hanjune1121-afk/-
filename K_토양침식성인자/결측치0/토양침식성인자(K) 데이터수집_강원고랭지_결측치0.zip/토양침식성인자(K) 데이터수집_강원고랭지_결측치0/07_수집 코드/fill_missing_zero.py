"""결측치 0 처리 — 토양침식성인자(K) 자료 두 묶음.

  1번 묶음: 토양침식성인자(K) 데이터수집_강원고랭지
  2번 묶음: 강원 고랭지 토양침식성인자 조사

원본 폴더는 그대로 두고 '<폴더 이름>_결측치0' 복사본을 만든 뒤, 자료 속 결측치만 0으로 바꾼다.
사이트에서 받은 원본 보고서(엑셀·PDF), 고시 원문, 설명용 표의 서식용 빈 칸(제목 줄 등)은 바꾸지 않는다.
결측치를 바꾸면 달라지는 평균·요약·미리보기 그림은 다시 계산해서 맞춘다.
바꾼 내용은 각 묶음의 '결측치_0처리_기록.csv'에 남긴다.

사용: python fill_missing_zero.py <1번 폴더> <2번 폴더> <출력 폴더>
"""
import re
import shutil
from copy import copy
import struct
import sys
import zipfile
from pathlib import Path

import numpy as np
import openpyxl
import pandas as pd
import rasterio
import shapefile

DATE = "2026-10-29"
BOM = b"\xef\xbb\xbf"
USES = ["논", "밭", "과수/상전", "초지", "임지"]
LOG_COLS = ["파일", "항목", "원래", "바꾼 값", "건수", "비고"]


def read_text(p):
    raw = p.read_bytes()
    text = raw.decode("utf-8-sig")
    nl = "\r\n" if "\r\n" in text else "\n"
    return text.replace("\r\n", "\n"), raw.startswith(BOM), nl


def write_text(p, text, bom, nl):
    p.write_bytes((BOM if bom else b"") + text.replace("\n", nl).encode("utf-8"))


def wavg(k, w):
    m = k.notna() & (w > 0)
    return float(np.average(k[m], weights=w[m])) if w[m].sum() > 0 else np.nan


def zipdir(folder, zpath):
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(folder.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(folder.parent).as_posix())


# ───────────────────────────── 1번 묶음 ─────────────────────────────
def package1(src, dst, me):
    log = []
    rel = lambda p: p.relative_to(dst).as_posix()
    f05 = dst / "05_지역별 K값 정리 (01 + 04 연결)"

    # 1) 지역 × 토양부호 표: 빈 K값 → 0
    det_p = f05 / "지역별_토양부호_면적_K값.csv"
    d = pd.read_csv(det_p, encoding="utf-8-sig")
    na = d["K값"].isna()
    for how, g in d[na].groupby("K값_연결방법"):
        names = "·".join(dict.fromkeys(g["토양통"].dropna()))
        note = (f"고시 표2에 K가 없는 토양통 ({names}), 면적 {g['합계'].sum():,.0f}ha" if how == "표2에 없음"
                else f"토양이 아닌 구역 ({names}), 면적 {g['합계'].sum():,.0f}ha라 평균에는 영향 없음")
        log.append([rel(det_p), f"K값 ({how})", "빈 칸", "0", f"{len(g)}행", note])
    d["K값"] = d["K값"].fillna(0.0)
    d.to_csv(det_p, index=False, encoding="utf-8-sig")

    # 2) 요약: 결측 토양통을 K = 0으로 넣어 면적가중 평균을 다시 계산, 면적이 없어 비던 칸 → 0
    sum_p = f05 / "지역별_K값_요약.csv"
    s = pd.read_csv(sum_p, encoding="utf-8-sig")
    old = s.copy()
    kcols = ["K_면적가중평균_전체"] + [f"K_면적가중평균_{u.replace('/', '·')}" for u in USES]
    for i, r in s.iterrows():
        soil = d[(d["파일"] == r["파일"]) & (d["K값_연결방법"] != "토양 아님")]
        s.at[i, kcols[0]] = round(wavg(soil["K값"], soil["합계"]), 4)
        for u, c in zip(USES, kcols[1:]):
            s.at[i, c] = round(wavg(soil["K값"], soil[u]), 4)
    blank = s[kcols].isna()
    for i, c in zip(*np.where(blank)):
        log.append([rel(sum_p), f"{kcols[c]} ({s.at[i, '파일']})", "빈 칸", "0", "1칸",
                    "그 토지이용 면적이 0ha라 평균이 없던 칸"])
    s[kcols] = s[kcols].fillna(0.0)
    changed = []
    for i in range(len(s)):
        for c in kcols:
            a, b = old.at[i, c], s.at[i, c]
            if pd.notna(a) and abs(a - b) > 1e-9:
                changed.append((s.at[i, "파일"], c, a, b))
                log.append([rel(sum_p), f"{c} ({s.at[i, '파일']})", f"{a:.4f}", f"{b:.4f}", "1칸",
                            "결측 토양통을 K = 0으로 넣어 평균을 다시 계산"])
    s.to_csv(sum_p, index=False, encoding="utf-8-sig")

    # 3) 정리 엑셀: 같은 시트 구성으로 다시 쓰기
    xl_p = f05 / "지역별_K값_정리.xlsx"
    order = openpyxl.load_workbook(xl_p, read_only=True).sheetnames
    with pd.ExcelWriter(xl_p, engine="openpyxl") as w:
        for sh in order:
            if sh == "요약":
                s.to_excel(w, sheet_name=sh, index=False)
            elif sh == "전체_토양부호별":
                d.to_excel(w, sheet_name=sh, index=False)
            else:
                part = d[d["파일"].str[:31] == sh]
                assert len(part), sh
                part.drop(columns=["파일"]).to_excel(w, sheet_name=sh, index=False)
    log.append([rel(xl_p), "모든 시트", "빈 칸 포함", "위 두 CSV와 같은 값", f"{len(order)}시트", "같은 시트 구성으로 다시 작성"])

    # 4) 자료설명: 결과표 숫자와 안내문
    t_p = dst / "00_자료설명.txt"
    text, bom, nl = read_text(t_p)
    lines = text.split("\n")
    i = next(k for k, l in enumerate(lines) if l.startswith("작성일:"))
    lines.insert(i + 1, f"결측치 0 처리: {DATE} (바꾼 내용은 결측치_0처리_기록.csv)")
    i = next(k for k, l in enumerate(lines) if l.startswith("  - build_k_tables.py"))
    lines.insert(i + 1, "  - fill_missing_zero.py : 결측치를 0으로 넣은 코드")
    i = next(k for k, l in enumerate(lines) if l.startswith("[지역별 면적가중 평균 K]"))
    j = i - 1
    while lines[j - 1].strip() == "":
        j -= 1
    lines[j:j] = ["4) 결측치는 0으로 넣었다.",
                  "   고시 표2에 없는 토양통과 토양이 아닌 구역의 K = 0,",
                  "   면적이 0ha라 평균이 없는 칸 = 0.",
                  "   평균은 결측 토양통을 K = 0으로 포함해 다시 계산했다."]
    i = next(k for k, l in enumerate(lines) if l.startswith("[지역별 면적가중 평균 K]"))
    rows = [k for k in range(i, i + 25) if lines[k].startswith("강원특별자치도")]
    assert len(rows) == len(s)
    for k, r in zip(rows, s.itertuples(index=False)):
        lines[k] = f"{r.지역:<30}{r.K_면적가중평균_전체:>10.4f}{r.K_면적가중평균_밭:>10.4f}{r[4]:>10.1f}"
    k = next(k for k, l in enumerate(lines) if l.startswith("※ 고시 표2에 없는 토양통"))
    lines[k] = "※ 고시 표2에 없는 토양통(본량·청룡·정동·매봉·우지)은 K = 0으로 넣었다."
    write_text(t_p, "\n".join(lines), bom, nl)
    log.append([rel(t_p), "결과표·안내문", "결측을 비운 기준의 값", "0을 넣은 기준의 값", f"요약값 {len(changed)}칸 반영", "4) 결측치 처리 단계 추가"])

    # 5) 바꾸지 않은 것
    log += [
        ["01_흙토람 토양통·부호 면적표 (원본)/*.xls, *.pdf", "보고서 빈 칸", "서식용 빈 칸(병합 셀)", "변경 없음", "",
         "사이트 원본 그대로 보존"],
        ["04_토양통별 K값 (환경부 고시 표2)/토양통별_K값.csv", "토양부호 '-'", "부호가 없는 토양통 표기", "변경 없음", "8행",
         "고시 원문 표기라 숫자 결측이 아님 (K값은 모두 있음)"],
        ["05_지역별 K값 정리 (01 + 04 연결)/흙토람_토양통목록_부호별토성.csv", "", "결측 없음", "변경 없음", "", ""],
    ]
    shutil.copy(me, dst / "07_수집 코드" / me.name)
    pd.DataFrame(log, columns=LOG_COLS).to_csv(dst / "결측치_0처리_기록.csv", index=False, encoding="utf-8-sig")
    return changed


# ───────────────────────────── 2번 묶음 ─────────────────────────────
ZERO_FIELDS = ["K_SG", "SAND_PCT", "SILT_PCT", "CLAY_PCT", "OC_PCT"]
OLD_DEF = "1 = SoilGrids 값이 없어 가장 가까운 필지 값으로 채움, 0 = 원값"
NEW_DEF = "1 = SoilGrids 값이 없는 필지(결측치) → K_SG·SAND_PCT·SILT_PCT·CLAY_PCT·OC_PCT를 0으로 넣음, 0 = 원값"
TITLES = {"평창군_대관령면": "평창 대관령면", "평창군_진부면": "평창 진부면", "강릉시_왕산면": "강릉 왕산면_안반데기",
          "강릉시_왕산면_안반데기": "강릉 왕산면_안반데기", "정선군_임계면": "정선 임계면", "정선군_여량면": "정선 여량면",
          "태백시_매봉산": "태백 매봉산_창죽동", "삼척시_하장면": "삼척 하장면_귀네미", "홍천군_내면": "홍천 내면_자운리",
          "인제군_가아리": "인제 가아리 일대", "양구군_해안면": "양구 해안면_펀치볼 만대리"}
OVERVIEW = ["평창군_대관령면", "평창군_진부면", "강릉시_왕산면_안반데기", "정선군_임계면", "정선군_여량면",
            "태백시_매봉산", "삼척시_하장면", "홍천군_내면", "인제군_가아리", "양구군_해안면"]


def dbf_layout(raw):
    nrec, hlen, rlen = struct.unpack("<IHH", raw[4:12])
    fields, off = {}, 1
    for i in range(32, hlen - 1, 32):
        if raw[i] == 0x0D:
            break
        fields[raw[i:i + 11].split(b"\0")[0].decode("ascii")] = (off, raw[i + 16], raw[i + 17])
        off += raw[i + 16]
    return nrec, hlen, rlen, fields


def zero_filled_parcels(dbf_p):
    """SG_FILLED = 1 인 레코드의 SoilGrids 값 칸만 0으로 덮어쓴다 (나머지 바이트는 그대로)."""
    raw = bytearray(dbf_p.read_bytes())
    nrec, hlen, rlen, f = dbf_layout(raw)
    so, sl, _ = f["SG_FILLED"]
    n = 0
    for i in range(nrec):
        b = hlen + i * rlen
        if raw[b] != 0x2A and raw[b + so:b + so + sl].strip() == b"1":
            for name in ZERO_FIELDS:
                o, ln, dec = f[name]
                raw[b + o:b + o + ln] = f"{0:.{dec}f}".rjust(ln).encode("ascii")
            n += 1
    dbf_p.write_bytes(bytes(raw))
    return n


def read_dbf(shp_p):
    r = shapefile.Reader(str(shp_p), encoding="euc-kr")
    return pd.DataFrame([list(x) for x in r.records()], columns=[x[0] for x in r.fields[1:]])


def fill_tif(p):
    with rasterio.open(p) as r:
        prof, a, nd, tags, btags = r.profile.copy(), r.read(1), r.nodata, r.tags(), r.tags(1)
    m = (a == nd) if nd is not None else np.zeros(a.shape, bool)
    if a.dtype.kind == "f":
        m |= np.isnan(a)
    n = int(m.sum())
    if n:
        prof.update(nodata=None)
        with rasterio.open(p, "w", **prof) as w:
            w.write(np.where(m, 0, a).astype(a.dtype), 1)
            w.update_tags(**tags)
            w.update_tags(1, **btags)
    return n, nd


def setup_font():
    import matplotlib
    matplotlib.use("Agg")
    try:
        import koreanize_matplotlib  # noqa: F401  (나눔고딕)
    except ImportError:
        matplotlib.rcParams["font.family"] = ["NanumGothic", "WenQuanYi Zen Hei", "DejaVu Sans"]
    matplotlib.rcParams["axes.unicode_minus"] = False


def k_cmap():
    from matplotlib.colors import LinearSegmentedColormap
    cm = LinearSegmentedColormap.from_list("kblue", ["#d3e4f8", "#2b7bd8", "#0d2f5e"])
    cm.set_under("#9a9a9a")  # 0 (결측치) 칸
    return cm


def draw_preview(a, n_miss, title, tile, out, vmin, vmax):
    import matplotlib.pyplot as plt
    from matplotlib.patches import Patch
    fig = plt.figure(figsize=(9.3, 10.8), dpi=100)
    ax = fig.add_axes([0.025, 0.065, 0.785, 0.845])
    im = ax.imshow(a, cmap=k_cmap(), vmin=vmin, vmax=vmax, interpolation="nearest")
    ax.set_xticks([]), ax.set_yticks([])
    for sp in ax.spines.values():
        sp.set_color("#c8c8c8")
    cax = fig.add_axes([0.837, 0.15, 0.04, 0.675])
    cb = fig.colorbar(im, cax=cax, ticks=np.arange(0.016, vmax + 1e-9, 0.0005), format="%.4f")
    cb.outline.set_visible(False)
    cb.ax.tick_params(labelsize=11, colors="#555555", length=0)
    cb.set_label("K  [t·ha·h/(ha·MJ·mm)]", fontsize=12, color="#555555", labelpad=10)
    sub = f"도엽 {tile} · 평균 {a.mean():.4f} · 범위 {a.min():.4f}~{a.max():.4f}"
    if n_miss:
        sub += f" · 결측 {n_miss:,}칸 → 0"
        fig.legend(handles=[Patch(color="#9a9a9a", label="0 (결측치)")], loc="lower left",
                   bbox_to_anchor=(0.815, 0.085), frameon=False, fontsize=11)
    fig.text(0.025, 0.955, f"{title} · 토양침식성인자(K)", fontsize=20, color="#222222")
    fig.text(0.025, 0.928, sub, fontsize=12, color="#555555")
    fig.text(0.02, 0.018, "SoilGrids 250m 기반 · 10개 지역 공통 색 범위 · 회색 = 결측치(0으로 넣음)",
             fontsize=10.5, color="#777777")
    fig.savefig(out, dpi=100, facecolor="white")
    plt.close(fig)


def draw_overview(grids, out, vmin, vmax):
    import matplotlib.pyplot as plt
    fig = plt.figure(figsize=(24, 12.6), dpi=100)
    W, H, X0, Y0, DX, DY = 0.129, 0.305, 0.125, 0.552, 0.1545, 0.419
    im = None
    for k, (name, a) in enumerate(grids):
        ax = fig.add_axes([X0 + (k % 5) * DX, Y0 - (k // 5) * DY, W, H])
        im = ax.imshow(a, cmap=k_cmap(), vmin=vmin, vmax=vmax, interpolation="nearest")
        ax.set_xticks([]), ax.set_yticks([])
        for sp in ax.spines.values():
            sp.set_color("#c8c8c8")
        ax.set_title(f"{TITLES[name]}\n평균 {a.mean():.4f}", fontsize=15, color="#222222", pad=6)
    cax = fig.add_axes([0.885, 0.2, 0.015, 0.59])
    cb = fig.colorbar(im, cax=cax, ticks=np.arange(0.016, vmax + 1e-9, 0.0005), format="%.4f")
    cb.outline.set_visible(False)
    cb.ax.tick_params(labelsize=13, length=0)
    cb.set_label("K  [t·ha·h/(ha·MJ·mm)]", fontsize=14, labelpad=10)
    fig.text(0.017, 0.955, "강원 고랭지 10개 지역 토양침식성인자(K) — 공통 색 범위", fontsize=22, color="#222222")
    fig.text(0.017, 0.022, "SoilGrids 250m 기반 · 지역 간 차이가 작음(약 0.016~0.018) — 전지구 자료의 해상도 한계 · "
                           "회색 = 결측치(0으로 넣음)", fontsize=13, color="#777777")
    fig.savefig(out, dpi=100, facecolor="white")
    plt.close(fig)


def package2(src, dst, me):
    log = []
    rel = lambda p: p.relative_to(dst).as_posix()
    farm = dst / "토양침식성인자(K)_팜맵필지"
    grid = dst / "토양침식성인자(K)_격자(DEM 90m 정합)"
    hwsd = dst / "토양특성_FAO HWSD v2(1km)"
    stats = {}

    # 1) 팜맵 필지 SHP: SoilGrids 결측 필지(SG_FILLED = 1)의 보간값 → 0
    for folder in sorted(p for p in farm.iterdir() if p.is_dir()):
        shp_p = next(folder.glob("*.shp"))
        before = read_dbf(shp_p)
        n = zero_filled_parcels(shp_p.with_suffix(".dbf"))
        after = read_dbf(shp_p)
        assert n == int(before["SG_FILLED"].sum())
        assert (after.drop(columns=ZERO_FIELDS) == before.drop(columns=ZERO_FIELDS)).all().all()
        assert (after.loc[after["SG_FILLED"] == 1, ZERO_FIELDS] == 0).all().all()
        stats[folder.name] = (before, after, n)
        if n:
            log.append([rel(shp_p.with_suffix(".dbf")), "K_SG·SAND_PCT·SILT_PCT·CLAY_PCT·OC_PCT (SG_FILLED = 1)",
                        "가장 가까운 필지 값으로 보간된 결측", "0", f"{n}필지",
                        f"전체 {len(before):,}필지의 {n / len(before) * 100:.1f}% · K_HWSD는 값이 있어 그대로"])
        xml_p = next(folder.glob("2026_meta_*.xml"))
        raw = xml_p.read_bytes()
        t = raw.decode("utf-8-sig")
        assert t.count(OLD_DEF) == 1
        t = t.replace(f"'SG_FILLED', '보간여부', '정수', '{OLD_DEF}'", f"'SG_FILLED', '결측(0처리)여부', '정수', '{NEW_DEF}'")
        assert NEW_DEF in t and OLD_DEF not in t
        if n:
            k = after["K_SG"]
            t, c = re.subn(r"K_SG 평균 [0-9.]+ \(범위 [0-9.]+~[0-9.]+\)",
                           f"K_SG 평균 {k.mean():.4f} (범위 0~{k.max():.4f}, SoilGrids 결측 {n}필지는 0)", t)
            assert c == 1
        xml_p.write_bytes((BOM if raw.startswith(BOM) else b"") + t.encode("utf-8"))
    log.append(["토양침식성인자(K)_팜맵필지/*/2026_meta_*.xml", "SG_FILLED 설명, K_SG 평균·범위",
                "보간 설명", "0 처리 설명·다시 계산한 평균", f"{len(stats)}개", "결측 필지가 있는 지역만 평균·범위가 바뀜"])

    # 2) 속성정의서·요약 엑셀 (서식은 그대로, 값만 수정)
    xp = next(farm.glob("*.xlsx"))
    wb = openpyxl.load_workbook(xp)
    ws = wb["속성정의서"]
    row = next(r for r in ws.iter_rows() if r[0].value == "SG_FILLED")
    row[1].value, row[3].value = "결측(0처리)여부", NEW_DEF
    ws = wb["지역별 요약"]
    head = {c.value: c.column for c in ws[3]}
    fmap = {"K_SG 평균": "K_SG", "모래(%)": "SAND_PCT", "미사(%)": "SILT_PCT", "점토(%)": "CLAY_PCT", "유기탄소(%)": "OC_PCT"}
    last = 3
    for r in range(4, ws.max_row + 1):
        name = ws.cell(r, 1).value
        if name:
            last = r
        if name not in stats or not stats[name][2]:
            continue
        before, after, n = stats[name]
        filled = before["SG_FILLED"] == 1
        for col, fld in fmap.items():
            c = ws.cell(r, head[col])
            new = c.value - before.loc[filled, fld].sum() / len(before)  # 보간값만 빼서 0으로 바꾼 평균
            log.append([rel(xp), f"지역별 요약 · {name} · {col}", f"{c.value:.4f}", f"{new:.4f}", "1칸", "결측 필지를 0으로 넣어 다시 계산"])
            c.value = new
        c = ws.cell(r, head["K_SG 최소"])
        log.append([rel(xp), f"지역별 요약 · {name} · K_SG 최소", f"{c.value:.4f}", "0.0000", "1칸", "결측 필지 = 0"])
        c.value = 0.0
        assert round(ws.cell(r, head["K_SG 최대"]).value, 5) == round(after["K_SG"].max(), 5)
    note = ws.cell(last + 1, 1)
    note.value = (f"※ 결측치 0 처리({DATE}): SoilGrids 값이 없던 필지(SG_FILLED = 1)는 K_SG·모래·미사·점토·유기탄소를 0으로 넣고 "
                  "평균·최소를 다시 계산함")
    note.font = copy(ws.cell(last, 1).font)
    ws = wb["농경지분류별 K"]
    for r in range(4, ws.max_row + 1):
        name, cls = ws.cell(r, 1).value, ws.cell(r, 2).value
        if name not in stats or not stats[name][2]:
            continue
        before, after, _ = stats[name]
        if not (before.loc[before["CLSF_NM"] == cls, "SG_FILLED"] == 1).any():
            continue
        new = after.loc[after["CLSF_NM"] == cls, "K_SG"].mean()
        assert abs(before.loc[before["CLSF_NM"] == cls, "K_SG"].mean() - ws.cell(r, 5).value) < 1e-9
        log.append([rel(xp), f"농경지분류별 K · {name} · {cls}", f"{ws.cell(r, 5).value:.4f}", f"{new:.4f}", "1칸",
                    "결측 필지를 0으로 넣어 다시 계산"])
        ws.cell(r, 5).value = new
    wb.save(xp)

    # 3) 격자 GeoTIFF: NoData(-9999) → 0, NoData 설정 지움
    vals = []
    for p in sorted(grid.glob("*/*.tif")):
        n, nd = fill_tif(p)
        log.append([rel(p), "NoData 칸", f"{nd:g} (NoData)", "0" if n else "변경 없음", f"{n:,}칸",
                    "NoData 설정을 지워 0을 실제 값으로 씀" if n else "결측 없음"])
        if "토양침식성인자" in p.name:
            a = rasterio.open(p).read(1)
            vals.append(a[a > 0])
    v = np.concatenate(vals)
    vmin, vmax = np.floor(v.min() * 1e4) / 1e4, np.ceil(v.max() * 1e4) / 1e4  # 원래 그림과 같은 공통 색 범위

    # 4) HWSD: 토양단위 지도 NoData, 표토 속성표의 -3·-9 코드·빈 토성 코드 → 0
    p = hwsd / "HWSD2_SMU_강원.tif"
    n, nd = fill_tif(p)
    log.append([rel(p), "NoData 칸", f"{nd:g} (NoData)", "0", f"{n:,}칸", "0 = 토양단위 없음"])
    p = hwsd / "HWSD2_D1표토_토양단위속성.csv"
    text, bom, nl = read_text(p)
    lines = text.split("\n")
    head = lines[0].split(",")
    num = [head.index(c) for c in ["SAND(%)", "SILT(%)", "CLAY(%)", "ORG_CARBON(%)", "COARSE(%)"]]
    tex = head.index("TEXTURE_USDA")
    cnt = {"-3": 0, "-9": 0, "": 0}
    for i in range(1, len(lines)):
        if not lines[i]:
            continue
        cells = lines[i].split(",")
        assert len(cells) == len(head)
        for j in num:
            if cells[j].startswith("-"):
                cnt[cells[j].split(".")[0]] += 1
                cells[j] = "0.0" if "." in cells[j] else "0"
        if cells[tex] == "":
            cnt[""] += 1
            cells[tex] = "0"
        lines[i] = ",".join(cells)
    write_text(p, "\n".join(lines), bom, nl)
    log.append([rel(p), "모래·미사·점토·유기탄소·자갈", "-3 코드 (자료 없음)", "0", f"{cnt['-3']}칸", "토양단위 4357의 1번 성분"])
    log.append([rel(p), "모래·미사·점토·유기탄소·자갈", "-9 코드 (자료 없음)", "0", f"{cnt['-9']}칸", "토양단위 7001"])
    log.append([rel(p), "TEXTURE_USDA", "빈 칸", "0", f"{cnt['']}칸", "위 두 행"])
    log.append(["", "참고: K_HWSD 값", "", "변경 없음", "",
                "K_HWSD는 처음부터 결측 성분을 빼고 계산된 값이라(4357 = 0.018477) 그대로 둠"])

    # 5) 미리보기 그림 다시 그리기
    setup_font()
    arrs = {}
    for folder in sorted(p for p in grid.iterdir() if p.is_dir()):
        tp = next(folder.glob("*_K_토양침식성인자.tif"))
        with rasterio.open(tp) as r:
            a = r.read(1)
        tile = tp.name.split("_")[0]
        n_miss = next(int(x[4].replace(",", "").replace("칸", "")) for x in log if x[0] == rel(tp))
        draw_preview(a, n_miss, TITLES[folder.name], tile, folder / f"{tile}_K_미리보기.png", vmin, vmax)
        arrs[folder.name] = a
    draw_overview([(k, arrs[k]) for k in OVERVIEW], grid / "K인자_격자_한눈에보기.png", vmin, vmax)
    log.append(["토양침식성인자(K)_격자(DEM 90m 정합)/*_K_미리보기.png, K인자_격자_한눈에보기.png", "미리보기 그림",
                "흰색 = 자료 없음", "회색 = 0(결측치)", f"{len(arrs) + 1}장", "평균은 0을 넣은 값으로 다시 계산"])

    # 6) 바꾸지 않은 것
    sg = [(q, int((rasterio.open(q).read(1) == 0).sum())) for q in sorted((dst / "토양특성_SoilGrids(250m)").glob("*/*.tif"))]
    log.append(["토양특성_SoilGrids(250m)/*/*.tif", "자료 없는 칸", "원래 0으로 저장됨", "변경 없음",
                f"{sum(n for _, n in sg):,}칸", f"{len(sg)}개 파일 · 이미 0이라 바꿀 것 없음"])
    log.append(["K인자 산정방법 및 참고자료/*.xlsx, 속성정의서 시트", "빈 칸", "제목 줄·구분 줄 등 서식용 빈 칸", "변경 없음", "",
                "자료 값이 아님"])

    # 7) README 안내
    rp = dst / "README.txt"
    text, bom, nl = read_text(rp)
    text = text.rstrip("\n") + "\n\n" + "\n".join([
        f"[결측치 0 처리 ({DATE})]",
        "- 팜맵필지 SHP: SoilGrids 값이 없던 필지(SG_FILLED = 1)는 가장 가까운 필지 값 대신",
        "  K_SG·SAND_PCT·SILT_PCT·CLAY_PCT·OC_PCT를 0으로 넣음 (K_HWSD는 값이 있어 그대로)",
        "- 격자 GeoTIFF: 자료 없음(-9999) 칸을 0으로 넣고 NoData 설정을 지움",
        "- HWSD: 토양단위 지도의 자료 없음(65535) 칸, 표토 속성표의 -3·-9 코드와 빈 토성 코드를 0으로 넣음",
        "- SoilGrids 원자료: 자료 없는 칸이 원래 0으로 저장돼 있어 그대로 둠",
        "- 요약 엑셀·메타데이터(xml)·미리보기 그림은 0을 넣은 값으로 다시 계산",
        "- 바꾼 곳과 건수: 결측치_0처리_기록.csv / 처리 코드: K인자 산정방법 및 참고자료/fill_missing_zero.py",
        "※ K = 0은 침식이 일어나지 않는다는 뜻이므로, 0을 넣은 칸·필지는 RUSLE 토양유실량도 0이 됩니다.",
    ]) + "\n"
    write_text(rp, text, bom, nl)
    shutil.copy(me, dst / "K인자 산정방법 및 참고자료" / me.name)
    pd.DataFrame(log, columns=LOG_COLS).to_csv(dst / "결측치_0처리_기록.csv", index=False, encoding="utf-8-sig")
    return {k: v[2] for k, v in stats.items()}


def main(src1, src2, out):
    src1, src2, out = Path(src1), Path(src2), Path(out)
    out.mkdir(parents=True, exist_ok=True)
    me = Path(__file__).resolve()
    dst1, dst2 = out / f"{src1.name}_결측치0", out / f"{src2.name}_결측치0"
    for d in (dst1, dst2):
        if d.exists():
            shutil.rmtree(d)
    shutil.copytree(src1, dst1)
    shutil.copytree(src2, dst2)
    changed = package1(src1, dst1, me)
    filled = package2(src2, dst2, me)
    for d in (dst1, dst2):
        zipdir(d, out / f"{d.name}.zip")
    print("1번 요약 변경:", *[f"{f} {c}: {a:.4f} → {b:.4f}" for f, c, a, b in changed], sep="\n  ")
    print("2번 0 처리 필지:", filled)


if __name__ == "__main__":
    main(*sys.argv[1:4])
