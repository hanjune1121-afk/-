"""흙토람(soil.rda.go.kr) > 통계자료 > 토양통계 원본 보고서 내려받기.
사이트에서 보고서 버튼을 누를 때와 같은 요청을 보내고, 보고서 서버의 내보내기(엑셀·PDF)를 그대로 저장한다.
  - 토양통·부호 > 토양별 토지이용 추천표           (sel_cbo=7)
  - 토양특성 > 표토토성·표토 자갈함량·구조·배수등급·침식등급 (sel_cbo=1)
사용: python fetch_heuktoram.py <저장폴더> [soilsign|props] [i/n: n개로 나눠 받을 때 i번째]
"""
import json, subprocess, sys, time
from pathlib import Path

REGIONS = [  # (파일명, 전체주소, sido, sgg, umd, ri)
    ("01_평창군_대관령면", "강원특별자치도 평창군 대관령면", "51", "760", "380", ""),
    ("02_평창군_진부면", "강원특별자치도 평창군 진부면", "51", "760", "360", ""),
    ("03_강릉시_왕산면", "강원특별자치도 강릉시 왕산면", "51", "150", "320", ""),
    ("03-1_강릉시_왕산면_대기리(안반데기)", "강원특별자치도 강릉시 왕산면 대기리", "51", "150", "320", "26"),
    ("04_정선군_임계면", "강원특별자치도 정선군 임계면", "51", "770", "350", ""),
    ("05_정선군_여량면", "강원특별자치도 정선군 여량면", "51", "770", "370", ""),
    ("06_태백시_창죽동(매봉산)", "강원특별자치도 태백시 창죽동", "51", "190", "111", ""),
    ("07_삼척시_하장면", "강원특별자치도 삼척시 하장면", "51", "230", "320", ""),
    ("07-1_삼척시_하장면_한소리(귀네미마을)", "강원특별자치도 삼척시 하장면 한소리", "51", "230", "320", "27"),
    ("08_홍천군_내면", "강원특별자치도 홍천군 내면", "51", "720", "390", ""),
    ("08-1_홍천군_내면_자운리", "강원특별자치도 홍천군 내면 자운리", "51", "720", "390", "25"),
    ("09_인제군_인제읍", "강원특별자치도 인제군 인제읍", "51", "810", "250", ""),
    ("09-1_인제군_인제읍_가아리", "강원특별자치도 인제군 인제읍 가아리", "51", "810", "250", "28"),
    ("10_양구군_해안면(펀치볼)", "강원특별자치도 양구군 해안면", "51", "800", "340", ""),
    ("10-1_양구군_해안면_만대리", "강원특별자치도 양구군 해안면 만대리", "51", "800", "340", "23"),
]
REPORTS = {
    "soilsign": [("토양통부호", "7", "")],
    "props": [("표토토성", "1", "2"), ("표토자갈함량", "1", "1"), ("구조", "1", "11"),
              ("배수등급", "1", "9"), ("침식등급", "1", "3")],
}
RD_SUFFIX = "/rfn [http://report.naas.go.kr:8081/DataServer/rdagent.jsp] /rsn [soildb] /rfonttype50u"


def curl(args, out, tries=8):
    for _ in range(tries):
        r = subprocess.run(["curl", "-s", "-m", "150", "-o", str(out)] + args)
        if r.returncode == 0 and out.exists() and out.stat().st_size > 0:
            return True
        time.sleep(3)
    return False


def main(dst, kind="soilsign", shard="0/1"):
    dst = Path(dst); dst.mkdir(parents=True, exist_ok=True)
    si, sn = map(int, shard.split("/"))
    log = []
    jobs = [(r, g) for g in REGIONS for r in REPORTS[kind]]
    for (label, cbo, sub), (rname, addr, sido, sgg, umd, ri) in jobs[si::sn]:
        name = rname if kind == "soilsign" else f"{rname}_{label}"
        meta = dst / f"{name}.json"
        done = all((dst / f"{name}.{e}").exists() and (dst / f"{name}.{e}").stat().st_size > 0 for e in ("xls", "pdf"))
        form = {"mode": "chart.report", "sel_cbo": cbo, "sel_subcbo": sub, "sel_cropcbo": "", "cropnm": "",
                "flag": "2", "fulladdr": addr, "sido_cd": sido, "sgg_cd": sgg, "umd_cd": umd, "ri_cd": ri}
        if done and (dst / f"{name}.req.json").exists():
            log.append(json.load(open(dst / f"{name}.req.json", encoding="utf-8"))); continue
        args = ["-X", "POST", "https://soil.rda.go.kr/cmm/common/ajaxCall.do"]
        for k, v in form.items():
            args += ["--data-urlencode", f"{k}={v}"]
        if not curl(args, meta):
            print("FAIL meta", name); continue
        d = json.load(open(meta, encoding="utf-8"))
        if str(d.get("dataCnt", "0")) == "0":
            print(name, "no data"); meta.unlink(); continue
        for et in ("xls", "pdf"):
            out = dst / f"{name}.{et}"
            a = ["-X", "POST", "https://report.naas.go.kr/ReportingServer/service",
                 "--data-urlencode", "opcode=500", "--data-urlencode", f"mrd_path={d['rdUrl']}",
                 "--data-urlencode", f"mrd_param={d['param']}{RD_SUFFIX}",
                 "--data-urlencode", f"export_type={et}", "--data-urlencode", "protocol=file"]
            ok = (out.exists() and out.stat().st_size > 0) or curl(a, out)
            print(name, et, ok, out.stat().st_size if ok else 0, "rows", d.get("dataCnt"))
        rec = {"파일": name, "주소": addr, "요청": form, "응답": d}
        json.dump(rec, open(dst / f"{name}.req.json", "w", encoding="utf-8"), ensure_ascii=False)
        log.append(rec)
        meta.unlink()
    if sn > 1:
        return  # 나눠 받을 때는 마지막에 shard 없이 한 번 더 실행해 기록을 모은다
    for f in dst.glob("*.req.json"):
        f.unlink()
    json.dump(log, open(dst / "_요청기록.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main(*sys.argv[1:4])
